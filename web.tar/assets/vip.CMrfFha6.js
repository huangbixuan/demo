const s="/assets/vip-Bhgj_Qpm.png";export{s as _};
